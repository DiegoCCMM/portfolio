package main

import (
    "fmt"
    "servistas/internal/msgsys"
    "servistas/pkg/cltvts"
    "strconv"
)

func main() {
    var texto string
    
    // obtener hot:puerto de este gestor de vistas del argumento
    me := os.Args[1]
    
    // inicializar sistema mensajería de gestor de vistas
    ms := msgsys.Make(self)

    // añadir código
    
}