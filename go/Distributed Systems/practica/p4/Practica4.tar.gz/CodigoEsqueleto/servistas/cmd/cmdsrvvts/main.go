/*
    Ejecutable del gestor de vistas
*/
package main

import (
    "fmt"
   "servistas/internal/comun"
   "servistas/internal/srvvts"
)

func main() {
    // obtener hot:puerto de este gestor de vistas del argumento
    me := os.Args[1]
    
    // inicializar sistema mensajería de gestor de vistas
    ms := msgsys.Make(me)
    
    // Completar codigo
}