/*
    paquete "comun" donde reside el código común compartido por
    los diferentes paquetes de este modulo
*/
package comun

import (
	"encoding/gob"
	"fmt"
	"net"
	"os"
	"servistas/internal/srvvts"
	"servistas/internal/msgsys"
)

type Vista struct {
    NumVista    int
    Primario    HostPuerto
    Copia       HostPuerto
}

func CheckError(err error, comment string) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "Fatal error: %s -- %s", err.Error(), comment)
		os.Exit(1)
	}
}
