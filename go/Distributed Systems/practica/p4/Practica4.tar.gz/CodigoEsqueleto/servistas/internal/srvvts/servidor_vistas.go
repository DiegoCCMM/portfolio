/*
    Package srvvts implementa servicio de vistas para gestión de réplicas
*/
package srvvts


import (
	"fmt"
	"servistas/internal/comun"
	"servistas/internal/msgsys"
	
	// paquetes adicionales si necesario
)

const (
    latidosFallidos = 4     // nº látidos fallidos para decidir fallo definitivo
    intervaloLatidos = 50   // en milisegundos
)

type tEstadoServVistas struct {
    tick chan Time
    
    // Campos adicionales del estado de información que debe guardar
    // este gestor de vistas
}

// InitServidorVistas ejecuta 
func InitServidorVistas() {
    fmt.Println("servidor_gv")
    
    e := new(estadoServVistas)

    // iniciar hilo de monitorización de fallos
    e.tick := time.Tick(intervaloLatidos * time.Millisecond)
    
    // Tratar mensajes de clientes y ticks periodicos de procesado de situacion
    for {
        e.tratarEventos()
    }
}

// Tratar eventos de recepción de mensajes,
// eventos periodicos de procesado de situacion de este servidor
func (e *estadoServVistas) tratarEventos(tick ) {
    
    // select con canales relacionados con eventos a procesar
    
}