package integracion_test

import (
    "fmt"
    "os"
    "os/exec"
    "servistas/internal/comun"
    "servistas/internal/srvvts"
    "servistas/pkg/cltvts"
    "testing"
)

const (
    MAQUINA1 = "127.0.0.1"
    MAQUINA2 = "127.0.0.1"
    MAQUINA3 = "127.0.0.1"
    PUERTO1 = "29000"
    PUERTO2 = "29002"
    PUERTO3 = "29003"
)

func TestMain(m *testing.M) {
    // setup of tests


    /* Obtain flags or env data ??
    flag.Parse()
    err := godotenv.Load(os.ExpandEnv("./../.env"))
    if err != nil {
        log.Fatalf("Error getting env %v\n", err)
    }
*/
    // Crear procesos en maquinas remotas : servidor de vistas
    startRemoteProcesses()

    // Run tests
    exitCode := m.Run()

    // clean up context left
    // eliminar procesos en máquinas remotas
    stopRemoteProcesses()

    os.Exit(exitCode)
}

func startRemoteProcesses(maquina, path string) {
    // Poner en marcha servidor de vistas y clientes, uno por maquina
    // mediante ssh
    // Una opción
    // exec.Command("ssh ", maquina, 
    //             " \"go run " + pathEjecutable + maquina+ puerto " &\"").Run
}

func stopRemoteProcesses(maquina string) {
    // Parar procesos distribuidos con ssh
    // una opción :
    // exec.Command("ssh ", maquina", " \"go run pkill go \"").Run
}

func TestPrimero(t *testing.T) {

    // completar código con otras funciones test para cada pruieba
}

