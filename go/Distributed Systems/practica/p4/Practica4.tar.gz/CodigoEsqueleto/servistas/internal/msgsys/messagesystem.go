package msgsys

import (
	"bufio"
	"servistas/internal/comun"
	"encoding/gob"
	"fmt"
	"net"
	"os"
)

type HostPuerto string  // "nombredns:puerto" o "numIP:puerto"

type Message interface{} //tipo generico, incluye todos los tipos existentes

// tipos mensajes concretos :
//                      Latido, VistaTentativa, VistaValida, DameVistaValida
type MsgLatido struct {
    NumVista    uint
    Remitente   HostPuerto
}

type MsgVista struct {
    comun.Vista
}

type MsgFin struct{}

type MessageSystem struct {
	mbox  chan Message
	done  chan bool
	me    HostPuerto
}

const (
	MAXMESSAGES = 10000
)

func (ms MessageSystem) Send(destinatario HostPuerto, msg Message) {
	tcpAddr, err := net.ResolveTCPAddr("tcp", string(destinatario))
	comun.checkError(err, "Problema creación dirección tcp en Send")
	
	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	comun.checkError(err, "Problema con DialTCP en Send")
	
	// fmt.Printf("Message for encoder: %#v \n", msg)
	encoder := gob.NewEncoder(conn)
	err = encoder.Encode(&msg)
	
	conn.Close()
}

func (ms *MessageSystem) Receive() (msg Message) {
	msg = <-ms.mbox
	return msg
}

func Make(whoIam HostPuerto) (ms MessageSystem) {
	ms.me = whoIam
	ms.mbox = make(chan Message, MAXMESSAGES)
	ms.done = make(chan bool)
	
	// Registrar tipos mensajes para decodificación con Decode(&receptor)
	gob.Register(MsgLatido{})
	gob.Register(MsgVista{})
	gob.Register(MsgFin{})

	go func() {
		listener, err := net.Listen("tcp", string(destinatario))
		comun.checkError(err, "Problema aceptación en New")
		fmt.Println("Process listening at " + string(destinatario))
		defer close(ms.mbox)
		for {
			select {
			case <-ms.done:
				return
			default:
				conn, err := listener.Accept()
				checkError(err, "Problema aceptación en New")
				decoder := gob.NewDecoder(conn)
				var msg Message
				err = decoder.Decode(&msg)
				conn.Close()
				ms.mbox <- msg
			}
		}
	}()
	return ms
}

func (ms *MessageSystem) Stop() {
	ms.done <- true
}
