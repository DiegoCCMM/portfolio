/*
   Package srvvts implementa servicio de vistas para gestión de réplicas
*/
package srvvts

import (
	"log"
	"os"
	"servistas/v2/internal/gvcomun"
	"servistas/v2/internal/msgsys"
	"time"
	// paquetes adicionales si necesario
)

type ServVistas struct {
	msgsys.MsgSys
	doneTicker chan struct{}

	// COMPLETAR CON ESTRUCTURA DATOS de ESTADO de GESTOR DE VISTA ????????

}

func Make(me msgsys.HostPuerto) ServVistas {
	// poner microsegundos y PATH completo de fichero codigo en logs
	gvcomun.ChangeLogPrefix()

	//log.Println("Puesta en marcha de servidor_gv")

	// Registrar tipos de mensaje de gestión d vistas
	gvcomun.RegistrarTiposMensajesGV()

	// crear estructura datos estado del servidor
	return ServVistas{
		// Crear channel msgsys
		MsgSys:     msgsys.MakeMsgSys(me),
		doneTicker: make(chan struct{}),

		//CAMPOS ADICIONALES DEL LITERAL DE ESTRUCTURA DATOS DEL GV ???????
	}
}

// Poner en marcha el servidor de vistas/gestor de vistas
func (sv *ServVistas) Start() {
	// crea generador de eventos ticker en periodos de envio de latido
	go sv.ticker()

	// Tratar mensajes de clientes y ticks periodicos de procesado de situacion
	// Termina ejecución cuando recibe mensaje tipo MsgFin.
	sv.ProcessAllMsg(sv.procesaMensaje) // Este metodo esta en paquete "msgsys"
}

func (sv *ServVistas) Stop() {
	// primero cerrar terminación (done) para que ticker
	// pare de enviar MsgTickInterno a buzon
	close(sv.doneTicker)

	// Esperar que goroutina ticker llegue a done por el time.Sleep
	time.Sleep(2 * gvcomun.INTERVALOLATIDOS * time.Millisecond)

	//
	sv.CloseMessageSystem()
}

// ticker to run through all the execution
func (sv *ServVistas) ticker() {
iteracion:
	for {
		select {
		case <-sv.doneTicker:
			//log.Println("Done with receiving Messages from TICKER!!!")
			break iteracion // Deja ya de generar  Ticks !!!

		default:
			time.Sleep(gvcomun.INTERVALOLATIDOS * time.Millisecond)
			sv.InternalSend(gvcomun.MsgTickInterno{})
		}
	}
}

func (sv *ServVistas) procesaMensaje(m msgsys.Message) {
	//log.Printf("----Recibido mensaje : %#v\n", m)

	switch x := m.(type) {
	case gvcomun.MsgLatido:
		sv.trataLatido(x)
	case gvcomun.MsgPeticionVistaValida:
		log.Println("Recibido peticion vista valida")
	case gvcomun.MsgPeticionPrimario:
		sv.trataPeticionPrimario(x.Remitente)
	case gvcomun.MsgTickInterno:
		sv.procesaSituacionReplicas()
	case gvcomun.MsgFin:
		log.Println("Recibido FIN")
		sv.Stop() // Eliminar el servidor de vistas !!
		os.Exit(0)
	default:
		log.Printf(
			"Llega mensaje TIPO DESCONOCIDO en servidor_vistas.go!! %#v\n", m)
	}
}

/// RESTO DE FUNCIONES DEL GESTOR DE VISTAS A IMPLEMENTAR ?????????
