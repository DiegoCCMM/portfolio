/*
    paquete cltvts donde se implementa el código de comunicación
    de clientes con el servidor de vistas
*/

package cltvts

import (
    "fmt"
	"servistas/internal/comun"
	"servistas/internal/msgsys"
)

