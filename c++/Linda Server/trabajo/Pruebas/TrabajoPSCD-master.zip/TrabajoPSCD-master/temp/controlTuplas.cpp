#include "controlTuplas.hpp"
#include <cassert>
#include <iostream>

//-----------------------------------------------------
ControlTuplas::ControlTuplas() {
	//set<string> a();
	//vacio(a);	// Creamos el arbol vacio donde se guardarán las tuplas
	salir = false;
};

void ControlTuplas::anyadir(Tupla t){
	unique_lock<mutex> lck(mtx);
	cout << "z" << endl;
	a.emplace(t.to_string());
	cout << "a" << endl;
	esperandoTupla.notify_all();
	cout << "b" << endl;
	// Se ha insertado la tupla
};
	
void ControlTuplas::eliminar(Tupla& t){
	unique_lock<mutex> lck(mtx);
	bool is_in = a.find(t.to_string()) != a.end();
	while(!is_in && !salir){
		// No se ha encontrado la tupla
		esperandoTupla.wait(lck); // Se bloquea
		bool is_in = a.find(t.to_string()) != a.end();
	}
	if(salir){
		Tupla x(t.size()); // Creamos una tupla completamente vacia
		t = x;	// Que sera la que enviemos al cliente
	}
	else{
		// Le pasamos la tupla t con sus valores actualizados
		auto it=a.find(t.to_string());
   		a.erase(it);
		// Se ha borrado correctamente la tupla
	}
};

void ControlTuplas::leer(Tupla& t){
	unique_lock<mutex> lck(mtx);
	bool is_in = a.find(t.to_string()) != a.end();
	while(!is_in && !salir){
		esperandoTupla.wait(lck);
		bool is_in = a.find(t.to_string()) != a.end();
	}
	cout<<"fin bloqueo read"<<endl;
	if(salir){
		Tupla x(t.size()); // Creamos una tupla completamente vacia
		t = x;	// Que sera la que enviemos al cliente
	}
	// else: Los valores de t se han modificado
};

void ControlTuplas::finalizar(){
	unique_lock<mutex> lck(mtx);
	salir = true;
	esperandoTupla.notify_all();
}