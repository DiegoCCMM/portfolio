Para compilar el proyecto, utilizar el CMakeLists.txt alojado en la carpeta source/p4
