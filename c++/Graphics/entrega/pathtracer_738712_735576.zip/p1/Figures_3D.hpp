//
// Created by diego on 3/10/20.
//

#ifndef PRACTICAS_FIGURES_3D_HPP
#define PRACTICAS_FIGURES_3D_HPP

class Figures_3D{
public:
    double x, y ,z;
};

#endif //PRACTICAS_FIGURES_3D_HPP
