package aima.gui.demo.search;

import java.util.Iterator;
import aima.core.search.*;
import java.util.List;
import java.util.Properties;

import aima.core.agent.Action;
import aima.core.environment.eightpuzzle.*;
import aima.core.search.framework.GraphSearch;
import aima.core.search.framework.Problem;
import aima.core.search.framework.Search;
import aima.core.search.framework.SearchAgent;
import aima.core.search.informed.AStarSearch;
import aima.core.search.informed.GreedyBestFirstSearch;
import aima.core.search.local.SimulatedAnnealingSearch;
import aima.core.search.uninformed.DepthLimitedSearch;
import aima.core.search.uninformed.IterativeDeepeningSearch;
import aima.core.search.uninformed.*;//Selecciona todas
import aima.core.util.math.Biseccion;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class EightPuzzlePractica2  {
	static EightPuzzleBoard boardWithThreeMoveSolution = new EightPuzzleBoard(
			new int[] { 1, 2, 5, 3, 4, 0, 6, 7, 8 });;

	static EightPuzzleBoard random1 = new EightPuzzleBoard(new int[] { 1, 4, 2,
			7, 5, 8, 3, 0, 6 });

	static EightPuzzleBoard extreme = new EightPuzzleBoard(new int[] { 0, 8, 7,
			6, 5, 4, 3, 2, 1 });

	public static void main(String[] args) {
		PreparaTabla();

	}
	
	//Devuelve la cantidad de nodos generados por un algoritmo de busqueda en 
	// un determinado problema
	private static int ObtenerValores(Search search,Problem problema) {

			int vector=-1;
			try {
				SearchAgent agente = new SearchAgent(problema,search);
				double generatedNodes;
				if(agente.getInstrumentation().getProperty("nodesGenerated")==null)generatedNodes=0;
				else generatedNodes=Double.parseDouble(agente.getInstrumentation().getProperty("nodesGenerated"));
				vector=(int)generatedNodes;				
			}

	 catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
		return vector;
	
}

	//Devuelve en un vector de numero enteros la profundidad y el numero de nodos generados
	//por un algoritmo de busqueda en un problema determinado.
	private static int[] comprobarProfundidad(int profundidad,Problem problema,Search search){
		int[] vector = new int[2];
		vector[0]=0;
		vector[1]=0;

		SearchAgent agente;
		try {
			double depth, generatedNodes;
			agente = new SearchAgent(problema,search);
			
			String pathcostM =agente.getInstrumentation().getProperty("pathCost");
			if(pathcostM!=null)depth=Double.parseDouble(pathcostM);
			else depth=0;
			if(agente.getInstrumentation().getProperty("nodesGenerated")==null)generatedNodes=0;
			else generatedNodes=Double.parseDouble(agente.getInstrumentation().getProperty("nodesGenerated"));
			vector[0]=(int)depth;
			vector[1]=(int)generatedNodes;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vector;
	}
	
	private static void PreparaTabla(){
	

		int profundidad_inicial=2;
		int profundidad_final=24;
		int Ni_profundidad=23;
		int Ni_Algoritmo=4;
		
		int[] comprobaciones = new int[2];
		int[][] nodos = new int[profundidad_final+1][Ni_Algoritmo];
		for(int j = 0; j<Ni_profundidad;j++) {
			for(int x =0; x<Ni_Algoritmo;x++) {
				nodos[j][x]=0;
			}
		}
		System.out.println("----------------------------------------------------------------------------------------------------------");
		System.out.println("||    ||                     NODOS GENERADOS                   ||                   b*                    "); 
		System.out.println("----------------------------------------------------------------------------------------------------------");
		System.out.println("||   d||         BFS  |      IDS   |    A*h(1)   |    A*h(2)   ||    BFS  |    IDS  |  A*h(1) | A*h(2)  ||");
		System.out.println("----------------------------------------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------------------------------------");
		
		for(int profundidad = profundidad_inicial; profundidad<=profundidad_final;profundidad++){
			for(int i=0;i<100;i++){
				
				
				//Genero un estado inicial aleatorio
				EightPuzzleBoard tablero=GenerateInitialEightPuzzleBoard.randomIni();
				//Creo un tablero final 
				EightPuzzleBoard tableroFinal=GenerateInitialEightPuzzleBoard.random(profundidad,tablero);
				
				//Fijamos ese tablero final como tablero objetivo
				EightPuzzleGoalTest2.SetObjetive(tableroFinal);
						//new EightPuzzleGoalTest2(profundidad, tablero);
				//Defino el problema
				Problem problema=new Problem(tablero,EightPuzzleFunctionFactory.getActionsFunction(),EightPuzzleFunctionFactory.getResultFunction(),
						new EightPuzzleGoalTest2());
				//Genero el tipo de busqueda
				Search search = new AStarSearch(new GraphSearch(),
						new ManhattanHeuristicFunction2());
	
				//Empiezas siempre con el A(2)* porque es el max rapido la de Manhattan
				//Comprobamos que la profundidad hallada con el algoritmo de busqueda
				//A* se corresponde con la que estamos buscando.
				comprobaciones=comprobarProfundidad(profundidad,problema,search);
				
				//En el caso de no haberse encontrado con una solucion cuya profunidad sea la
				//buscada volvemos a repetir este proceso hasta hallar un problema con dicha
				//profundidad.
				while(comprobaciones[0]!=profundidad) {
					
					tablero=GenerateInitialEightPuzzleBoard.randomIni();
					//Creo un tablero final 
					tableroFinal=GenerateInitialEightPuzzleBoard.random(profundidad,tablero);
					
					EightPuzzleGoalTest2.SetObjetive(tableroFinal);

					//Defino el problema
					search = new AStarSearch(new GraphSearch(),
							new ManhattanHeuristicFunction2());
					
					problema=new Problem(tablero,EightPuzzleFunctionFactory.getActionsFunction(),EightPuzzleFunctionFactory.getResultFunction(),
							new EightPuzzleGoalTest2());
										
					comprobaciones=comprobarProfundidad(profundidad,problema,search);
					
				}
			
			//Problema AH(2)
			nodos[profundidad][1]+=comprobaciones[1];
			
			//Una vez encontrado ejecutamos el resto de algoritmos de busqueda.
			
			//Problema AH(1)
			search = new AStarSearch(new GraphSearch(),new MisplacedTilleHeuristicFunction2());
			nodos[profundidad][0]+=ObtenerValores(search,problema);
			
			
			//Problema BFS

			search = new BreadthFirstSearch();			 			
			nodos[profundidad][2]+=ObtenerValores(search,problema);
				 
			//Problema IDS	
			//Si la profundidad es superior a 10 no realizamos la busqueda con IDS ya que no
			//encontraremos solucion			
			if(profundidad<10) {
				search = new IterativeDeepeningSearch();		
				nodos[profundidad][3]+=ObtenerValores(search,problema);				
			}
					
		}

		 mostrar(nodos,profundidad);
		}
		System.out.println("----------------------------------------------------------------------------------------------------------");
	}
	
	//Mostramos por pantalla los resultados para una determinada profundidad.
	private static void mostrar(int[][] nodos,int profundidad) {
		//Definimos un vector para calcular las b* de los diferentes algoritmos
		double[] bs=new double[4];
		Biseccion z= new Biseccion();
		for(int i= 0;i<4;i++) {
			///Si es IDS y la profundidad mayor que 10,esto no se hace
			if(!(profundidad>=10 && i==3)) {
				z.setDepth (profundidad);
				z.setGeneratedNodes (nodos[profundidad][i]/100);
				bs[i]=z.metodoDeBiseccion(1.0000001,4.0,1E-10);				
			}
			
		}
		
		String p = String.valueOf(profundidad);
		String nodosBFS = String.valueOf(nodos[profundidad][2]/100);
		String nodosAStarH1 = String.valueOf(nodos[profundidad][0]/100); 
		String nodosAStarH2 = String.valueOf(nodos[profundidad][1]/100); 
		String nodosIDS;
		double biseccionBFS = bs[2];
		double biseccionIDS = bs[3];
		double biseccionAStarH1 = bs[0];
		double biseccionAStarH2 = bs[1];

		if (nodos[profundidad][3]/100 <= 0) {
		     nodosIDS = "----";
		}
		else {
			 nodosIDS = String.valueOf(nodos[profundidad][3]/100);
		}
		

		// Mostramos los resultados del algoritmo ejecutado
		System.out.format("|| %3s|| %10s   |%10s  | %10s  | %10s  ||   %.2f  |", p, nodosBFS, nodosIDS, nodosAStarH1, nodosAStarH2,  biseccionBFS);
		
		// Verificamos si el algoritmo IDS ha hallado la soluci�n
		if (biseccionIDS <= 0.0) {
			// No la ha encontrado
			System.out.format("  ----  ||");
		}
		else {
			// Si la ha encontrado
			System.out.format("  %.2f  ||", biseccionIDS);	
		}
		// Muestra el resto de las estad�sticas
		System.out.format("   %.2f  |  %.2f   ||\n",  biseccionAStarH1,  biseccionAStarH2);
		
		
	}
}