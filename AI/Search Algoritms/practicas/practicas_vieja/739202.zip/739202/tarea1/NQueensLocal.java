package aima.gui.demo.search;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import aima.core.*;
import aima.core.agent.Action;
import aima.core.environment.nqueens.AttackingPairsHeuristic;
import aima.core.environment.nqueens.NQueensBoard;
import aima.core.environment.nqueens.NQueensFitnessFunction;
import aima.core.environment.nqueens.NQueensFunctionFactory;
import aima.core.environment.nqueens.NQueensGoalTest;
import aima.core.search.framework.Problem;
import aima.core.search.framework.SearchAgent;
import aima.core.search.local.GeneticAlgorithm;
import aima.core.search.local.HillClimbingSearch;
import aima.core.search.local.Individual;
import aima.core.search.local.SimulatedAnnealingSearch;
import aima.core.search.local.HillClimbingSearch.SearchOutcome;
import aima.core.search.local.Scheduler;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class NQueensLocal {
	
	private static final int _tablero = 8;
	
	public static void main(String[] args) {
		
		nQueensClimbingSearch_Statistics(10000);

		nQueensRandomRestartHillClimbing();
		
		for(int k=10;k<100;k+=40) {
			for(double lam=0.05;lam<2.15;lam+=0.5) {
				for(int limit=100;limit<=2100;limit+=300) {
					nQueensAnnealing_Statistics(1000,k,lam,limit);
					
				}
			}
		}
		
		nQueensHillSimulatedAnnealingRestart(10,0.2,2100);

		for(int population =2;population<80;population+=12) {
			for(double p=0.1;p<0.9;p+=0.15) {
				nQueensGeneticAlgorithmSearch(p,population);
			}
		}

		

		
	}
	
	public static void nQueensClimbingSearch_Statistics(int numExperiments) {
		System.out.println("\nNQueens HillClimbing "+numExperiments+" estados iniciales diferentes -->");
		List<NQueensBoard> tableros= new ArrayList<NQueensBoard>();
		double fallos=0;
		double numero_pasos_fallo=0;
		double aciertos=0;
		double numero_pasos_acierto=0;
		int i=0;
		while(i<numExperiments) {
			try {
				
				// Comprobamos que no repetimos ningun tablero para evitar realizar
				//el mismo experimento 2 o m�s veces.
				NQueensBoard tableroinicial=new NQueensBoard(_tablero);
				while(tableros.contains(tableroinicial)) {
					tableroinicial=new NQueensBoard(_tablero);
				}
				tableros.add(tableroinicial);
				
				Problem problem = new Problem (tableroinicial,
						NQueensFunctionFactory.getCActionsFunction(),
						NQueensFunctionFactory.getResultFunction(),
						new NQueensGoalTest());
				
				HillClimbingSearch search = new HillClimbingSearch(
						new AttackingPairsHeuristic());
				
				SearchAgent agent = new SearchAgent(problem, search);
				
				if(search.getOutcome().equals(SearchOutcome.FAILURE)) {
					fallos++;
					numero_pasos_fallo+=agent.getActions().size();
				}
				else {
					aciertos++;
					numero_pasos_acierto+=agent.getActions().size();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
			
		}
		System.out.println("Fallos: "+fallos);
		System.out.format("Coste medio fallos: %.2f\n",numero_pasos_fallo/fallos);
		System.out.println("�xitos: "+aciertos);
		System.out.format("Coste medio �xitos: %.2f\n",numero_pasos_acierto/aciertos);
		
	}
	
	
	
	
	public static void nQueensRandomRestartHillClimbing() {
		List<NQueensBoard> tableros= new ArrayList<NQueensBoard>();
		boolean fin=true;
		double fallos=0;
		double numero_pasos_fallo=0;
		double aciertos=0;
		double numero_pasos_acierto=0;
		HillClimbingSearch search = null;
		
		while(fin) {					
			try {
				
				NQueensBoard tableroinicial=new NQueensBoard(_tablero);
				while(tableros.contains(tableroinicial)) {
					tableroinicial=new NQueensBoard(_tablero);
				}
				tableros.add(tableroinicial);
				
				Problem problem = new Problem (tableroinicial,
						NQueensFunctionFactory.getCActionsFunction(),
						NQueensFunctionFactory.getResultFunction(),
						new NQueensGoalTest());
				
				search = new HillClimbingSearch(
						new AttackingPairsHeuristic());
				
				SearchAgent agent = new SearchAgent(problem, search);
				
				
				if(search.getOutcome().equals(SearchOutcome.FAILURE)) {
					fallos++;
					numero_pasos_fallo+=agent.getActions().size();
				}
				else {
					fin=false;
					aciertos++;
					numero_pasos_acierto+=agent.getActions().size();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		System.out.println("Search Outcome= " + search.getOutcome());
		System.out.println("Final State=\n" + search.getLastSearchState());
		System.out.println("Numero intentos: "+(fallos+aciertos));
		System.out.println("Fallos: "+fallos);
		//Para evitar dividir por 0
		if(fallos==0) {
			fallos=1;
		}
		System.out.println("Coste medio fallos: "+(numero_pasos_fallo/fallos));
		System.out.println("Coste  �xito: "+(numero_pasos_acierto/aciertos));
		System.out.println("Coste medio �xito: "+(numero_pasos_acierto/aciertos));
		
	}
	
	
	public static void nQueensAnnealing_Statistics(int numExperiments,int k,double lam,int limit) {
		
		List<NQueensBoard> tableros= new ArrayList<NQueensBoard>();
		double fallos=0;
		double numero_pasos_fallo=0;
		double aciertos=0;
		double numero_pasos_acierto=0;
		int i=0;
		System.out.println("NQueensDemo Simulated Annealing con "+numExperiments +" estados iniciales diferentes -->");
		System.out.println("\nParametros Scheduler: Scheduler( "+k+", "+lam+", "+limit+" )");
		while(i<numExperiments) {
			try {				
				NQueensBoard tableroinicial=new NQueensBoard(_tablero);
				while(tableros.contains(tableroinicial)) {
					tableroinicial=new NQueensBoard(_tablero);
				}
				tableros.add(tableroinicial);
				
				Problem problem = new Problem (tableroinicial,
						NQueensFunctionFactory.getCActionsFunction(),
						NQueensFunctionFactory.getResultFunction(),
						new NQueensGoalTest());
				
				SimulatedAnnealingSearch search = new SimulatedAnnealingSearch(
						new AttackingPairsHeuristic(),new Scheduler(k,lam,limit));
				
				SearchAgent agent = new SearchAgent(problem, search);
				
				//SearchOutcome
				if(search.getOutcome().equals(SimulatedAnnealingSearch.SearchOutcome.FAILURE)) {
					fallos++;
					numero_pasos_fallo+=agent.getActions().size();
				}
				else {
					aciertos++;
					numero_pasos_acierto+=agent.getActions().size();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
			
		}
		System.out.println("Fallos: "+fallos);
		if(fallos==0) {
			fallos=1;
		}
		System.out.format("Coste medio fallos: %.2f\n",numero_pasos_fallo/fallos);
		System.out.println("Exitos: "+aciertos);
		if(aciertos==0) {
			aciertos=1;
		}
		System.out.format("Coste medio Exitos: %.2f\n",numero_pasos_acierto/aciertos);
		
	}
	
	
	
	
	public static void nQueensHillSimulatedAnnealingRestart(int k,double lam,int limit) {
		List<NQueensBoard> tableros= new ArrayList<NQueensBoard>();
		boolean fin=true;
		double fallos=0;

		double aciertos=0;
		double numero_pasos_acierto=0;
		SimulatedAnnealingSearch search = null;
		int i=0;
		System.out.println("\nParametros Scheduler: Scheduler( "+k+","+lam+", "+limit+" )");
		while(fin) {
			try {				
				NQueensBoard tableroinicial=new NQueensBoard(_tablero);
				while(tableros.contains(tableroinicial)) {
					tableroinicial=new NQueensBoard(_tablero);
				}
				tableros.add(tableroinicial);
				
				Problem problem = new Problem (tableroinicial,
						NQueensFunctionFactory.getCActionsFunction(),
						NQueensFunctionFactory.getResultFunction(),
						new NQueensGoalTest());
				
				 search = new SimulatedAnnealingSearch(
						new AttackingPairsHeuristic(), new Scheduler(k,lam,limit));
				
				SearchAgent agent = new SearchAgent(problem, search);
				
				
				if(search.getOutcome().equals(SimulatedAnnealingSearch.SearchOutcome.FAILURE)) {
					
					fallos++;
				}
				else {
					fin=false;
					aciertos++;
					numero_pasos_acierto+=agent.getActions().size();
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		i++;
		}
		
		System.out.println("Search Outcome= " + search.getOutcome());
		System.out.println("Final State=\n" + search.getLastSearchState());
		System.out.println("Numero de intentos: "+i);
		System.out.println("Fallos: "+fallos);
		System.out.format("Coste  �xito: %.2f\n",numero_pasos_acierto/aciertos);
		
	}
	
	public static void nQueensGeneticAlgorithmSearch(double probabilidad_mutacion,int poblacion) {

		try {
			NQueensFitnessFunction fitnessFunction = new NQueensFitnessFunction();
			// Generate an initial population
			Set<Individual<Integer>> population = new HashSet<Individual<Integer>>();
			for (int i = 0; i < poblacion; i++) {
				population.add(fitnessFunction
						.generateRandomIndividual(_tablero));
			}

			GeneticAlgorithm<Integer> ga = new GeneticAlgorithm<Integer>(
					_tablero,
					fitnessFunction.getFiniteAlphabetForBoardOfSize(_tablero),
					probabilidad_mutacion);

			Individual<Integer> bestIndividual = ga.geneticAlgorithm(
					population, fitnessFunction, fitnessFunction, 0L);
			System.out.println("Par�metros iniciales:  Poblaci�n:"+poblacion+", Probabilidad mutaci�n:"+probabilidad_mutacion);
			System.out.println("Max Time (1 second) Best Individual=\n"
					+ fitnessFunction.getBoardForIndividual(bestIndividual));
			System.out.println("Tama�o tablero      = " + _tablero);
			System.out.println("Fitness         = "
					+ fitnessFunction.getValue(bestIndividual));
			System.out.println("Es objetivo         = "
					+ fitnessFunction.isGoalState(bestIndividual));
			System.out.println("Tama�o de poblaci�n = " + ga.getPopulationSize());
			System.out.println("Iteraciones      = " + ga.getIterations());
			System.out.println("Tiempo            = "
					+ ga.getTimeInMilliseconds() + "ms.");
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
