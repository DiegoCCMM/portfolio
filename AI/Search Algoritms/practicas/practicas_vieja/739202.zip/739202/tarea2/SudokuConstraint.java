package aima.gui.sudoku.csp;

import java.util.ArrayList;
import java.util.List;

import aima.core.search.csp.Assignment;
import aima.core.search.csp.Constraint;
import aima.core.search.csp.Variable;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */
public class SudokuConstraint implements Constraint {
	private SudokuVariable v1;
	private SudokuVariable v2;
	private List<Variable> scope;

	public SudokuConstraint(Variable variable, Variable variable2) {
		v1=(SudokuVariable)variable;
		v2=(SudokuVariable)variable2;
		scope = new ArrayList<Variable>(2);
		scope.add(v1);
		scope.add(v2);
		
	}

	@Override
	public List<Variable> getScope() {
		// TODO Auto-generated method stub
		return scope;
	}

	@Override
	public boolean isSatisfiedWith(Assignment assignment) {
		// No pueden tener el mismo valor
		Integer value1=(Integer) assignment.getAssignment(v1);
		Integer value2= (Integer)assignment.getAssignment(v2);
		return value1==null||!value1.equals(value2);
	}

}
