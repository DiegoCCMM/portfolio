package aima.gui.sudoku.csp;
import aima.core.search.csp.Variable;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class SudokuVariable extends Variable {
	//x e y representar�n la posici�n donde se encuentra
	// el valor de la variable
	private int x;
	private int y;
	private int valor;

	public SudokuVariable(String string, int _x, int _y) {
		super(string);
		x=_x;
		y=_y;

	}

	public int getX() {

		return x;
	}

	public int getY() {

		return y;
	}

	public int getValue() {

		return valor;
	}

	public void setValue(int value) {
		valor=value;
		
	}

}
