package aima.gui.sudoku.csp;

import aima.core.search.csp.Assignment;
import aima.core.search.csp.ImprovedBacktrackingStrategy;
import java.util.stream.Stream; 

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class SudokuApp {
	public static void main(String[] args) {
		
		Sudoku[] lista=(Sudoku[]) union ((Sudoku[]) union (Sudoku.listaSudokus2("easy50.txt"),Sudoku.listaSudokus2("top95.txt")),Sudoku.listaSudokus2("hardest.txt"));
		

		ImprovedBacktrackingStrategy bts= new ImprovedBacktrackingStrategy(true,true,true,true);
		bts.setInference(ImprovedBacktrackingStrategy
				.Inference.FORWARD_CHECKING);
		SudokuProblem problema_sudoku;
		int sudokus_tratados=lista.length;
		int sudokus_completos=0;
		
		for(int i=0; i<lista.length;i++) {
			System.out.println("---------------");
			
			problema_sudoku= new SudokuProblem(lista[i].pack_celdasAsignadas());
			lista[i].imprimeSudoku();
			System.out.println("SUDOKU INCOMPLETO - Resolviendo ");
			double start= System.currentTimeMillis();
			Assignment sol= bts.solve(problema_sudoku);
			double end= System.currentTimeMillis();
			System.out.println("Time to solve = "+ (end -start)/1000+" segundos.");
			System.out.println(sol);
			Sudoku solucion= new Sudoku(sol);
			
			if((solucion.completo()) && solucion.correcto()) {
				sudokus_completos++;
				System.out.println("Sudoku solucionado correctamente.");
				System.out.println("SOLUCION:");
				solucion.imprimeSudoku();
			}
			
			System.out.println("+++++++++++++++++");

			
			
		}
		System.out.println("Numero de sudokus completados:"+sudokus_completos);
		System.out.println("Numero de sudokus solucionados:"+sudokus_tratados);
		

		

	}

	private static Sudoku[] union(Sudoku[] listaSudokus2, Sudoku[] listaSudokus22) {
		Sudoku[] result = Stream.of(listaSudokus2, listaSudokus22).flatMap(Stream::of).toArray(Sudoku[]::new);
		return result;
	}

}
