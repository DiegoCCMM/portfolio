package aima.gui.nqueens.csp;
import java.util.ArrayList;
import java.util.List;
import aima.core.search.csp.Assignment;
import aima.core.search.csp.Constraint;
import aima.core.search.csp.Variable;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class NQueensConstraint implements Constraint {
	private Variable v1;
	private Variable v2;
	private List<Variable> scope;
	private int diagonal;

	public NQueensConstraint(Variable variable, Variable variable2, int i) {
		// TODO Auto-generated constructor stub
		v1=variable;
		v2=variable2;
		scope = new ArrayList<Variable>(2);
		scope.add(v1);
		scope.add(v2);
		diagonal=i;
	}

	@Override
	public List<Variable> getScope() {
		// TODO Auto-generated method stub
		return scope;
	}

	@Override
	public boolean isSatisfiedWith(Assignment assignment) {
		// TODO Auto-generated method stub
		Object value1= assignment.getAssignment(v1);
		Object value2=assignment.getAssignment(v2);

		
		if(value1!=null && value2!=null) {
			//Para comprobar que 2 reinas no se atacan hay que  revisar que dichas reinas no se encuentran en la misma fila
			//ni en diagonal
			return(Math.abs((int)value1-(int)value2)!=Math.abs(diagonal) && !(value1.equals(assignment.getAssignment(v2))));
		}
		else {
			return true;
		}
		
	}

}
