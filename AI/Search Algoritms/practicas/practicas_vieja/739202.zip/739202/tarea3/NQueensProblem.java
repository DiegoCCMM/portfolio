package aima.gui.nqueens.csp;

import java.util.ArrayList;
import java.util.List;

import aima.core.search.csp.CSP;
import aima.core.search.csp.Domain;
import aima.core.search.csp.Variable;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */


public class NQueensProblem extends CSP{
	
    private static List<Variable> variables = null;
    
    /*
     * Construye el problema de las NQueens
     * 
     */
    public NQueensProblem() {
    	
    	super(construirVariables());
    	inicializar();
    	
        Domain domain;
        
        for (Variable var : getVariables()) {
             domain = new Domain(getQueenColumnsValues((NQueensVariable) var));
             setDomain(var, domain);
        }
        
    	doConstraint();
    }
    
    /*
     * Agrega a la lista de variables las 8 reinas,cada una en una columna diferente.
     * 
     */    
    private static List<Variable> construirVariables(){
    	variables = new ArrayList<Variable>();
    	for(int i=0; i<8;i++) {
    		variables.add(new NQueensVariable("Reina en columna["+i+"]",i,0));
    			
    		}
    	return variables;
    }
    
    /**
    *
    * @param var variable del Nqueens
    * @return Dominio de la variable,
    *         si tiene valor el dominio es el valor. Sino el dominio 0-7
    *         debido a que el tablero es de 8x8.
    */
   private static List<Integer> getQueenColumnsValues(NQueensVariable var) {
        List<Integer> list = new ArrayList<Integer>();
        if(var.getValue()!=0) {
        	list.add(new Integer(var.getValue()));
        }
        else {
            for(int i=0;i<8;i++) {
            		list.add(new Integer(i));
            }
        	
        }
 
        return list;
   }
   
   
   
   private void inicializar() {
	   for(int i=0;i<8;i++) {
		   NQueensVariable v=(NQueensVariable) variables.get(i);
		   v.setValue(0);
		   
	   }
   }
   
   /*
    * Se encarga de generar las restricciones que se han de cumplir para posicionar las 8 reinas.
    */
    private void doConstraint() {
    	for(int i=0;i<8;i++) {
    		
    		for(int j=i+1;j<8;j++) {
    			//Guardamos j-i debido a que en la clase constraint vamos a necesitarlo para
    			//comprobar si 2 reinas se encuentran en diagonal
    				 addConstraint(new NQueensConstraint(variables.get(i), variables.get(j),j-i));
    		}
    	}
    }

}
