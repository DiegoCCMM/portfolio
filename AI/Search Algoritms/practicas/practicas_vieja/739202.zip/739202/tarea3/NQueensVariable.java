package aima.gui.nqueens.csp;

import aima.core.search.csp.Variable;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */

public class NQueensVariable extends Variable {
	private int columna;
	private int diagonal;
	/*/
	 * Inicializamos la variable con el valor de la columna en la que posicionamos
	 * la reina y a�adimos un entero que llevar� el valor de la diagonal.
	 * Esta es la resta de las distintas columnas,que ser� utilizado en las restricciones.
	 */
	public NQueensVariable(String string, int _f, int i) {
		super(string);
		columna=_f;
		diagonal=i;
	}
	
	public int getColumn() {

		return columna;
	}
	
	public int getValue() {

		return diagonal;
	}
	public void setValue(int c) {
		diagonal=c;
	}
}
