package aima.gui.nqueens.csp;

import aima.core.environment.nqueens.NQueensBoard;
import aima.core.search.csp.Assignment;
import aima.core.search.csp.MinConflictsStrategy;
import aima.core.search.csp.Variable;
import aima.core.util.datastructure.XYLocation;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */


public class NQueensMinConflictApp {
	
	public static void main(String[] args) {
		
		int numero_intentos=5;				
		MinConflictsStrategy estrategia= null;
		NQueensProblem reinas_problema;
		double start = 0;
		double end = 0;
		Assignment sol = null;	
		
		
		while(sol==null) {
			estrategia= new MinConflictsStrategy(numero_intentos);
			reinas_problema= new NQueensProblem();
			start= System.currentTimeMillis();
			sol= estrategia.solve(reinas_problema);
			end= System.currentTimeMillis();	
			numero_intentos+=3;		
		}


			
		System.out.println(sol);
		System.out.println("Numero m�ximo de pasos "+ numero_intentos);
		System.out.println("Time to solve = "+ (end -start)/1000 +" segundos.");
		System.out.println("SOLUCION:");
			
		NQueensBoard tab=new NQueensBoard(8);
		tab.clear();

			for (Variable var : sol.getVariables()) {
		
			NQueensVariable v = (NQueensVariable) var;
			int columna=v.getColumn();
			int fila=(int)sol.getAssignment(v);
			tab.moveQueenTo(new XYLocation(fila,columna)); 
		}
		tab.print();
					
	}

}
