package aima.gui.nqueens.csp;
import aima.core.search.csp.Assignment;

/**
 * Alumno: Luis Garcia Garces
 * NIA: 739202 
 */
//No se ha requerido de su uso para este trabajo.
public class NQueensAssignment extends Assignment {

}
