'''
Practica 5 Inteligencia Artificial
Luis García Garcés
739202
'''

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop, Adam, SGD
from keras.callbacks import EarlyStopping
import time
import numpy as np
import P5_utils

print('Loading MNIST dataset...')
# Problem dimensions
img_rows, img_cols = 28, 28
num_pixels = img_rows * img_cols
num_classes = 10
# The data, split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train.reshape(60000, num_pixels)
x_test = x_test.reshape(10000, num_pixels)
x_train = x_train.astype('float32') / 255
x_test = x_test.astype('float32') / 255
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')
# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test  = keras.utils.to_categorical(y_test,  num_classes)
# Random permutation of training data
np.random.seed(0)
p = np.arange(x_train.shape[0])
np.random.shuffle(p)
x_train = x_train[p]
y_train = y_train[p]

print("")
print("Pruebas para un solo perceptron sin capas ocultas")
print("")
# Función para parar cuando ya no mejora el error de validacion
earlystop=EarlyStopping(monitor='val_loss', patience=5, 
                        verbose=1, mode='auto')

optimizadores = ['sgd','adam','rmsprop']
funcion_coste = ['categorical_crossentropy','mean_squared_error']
funcion_activacion = ['sigmoid','softmax','relu']
for i in funcion_activacion:
    # Perceptron de un solo nivel
    model = Sequential()
    model.add(Dense(10, activation=i, input_shape=(num_pixels,)))    
    for x in optimizadores:        
        for j in funcion_coste:
            model.compile(loss=j,
                      optimizer=x,
                      metrics=['accuracy'])
            
            t0 = time.clock()
            
            history = model.fit(x_train, y_train,
                                batch_size=128,
                                epochs=20,
                                validation_split=0.1,
                                callbacks=[earlystop],
                                verbose=0)
                
            train_time = time.clock() - t0
            print('%s %.3f%s' %  ('Training time: ', train_time, 's') )
            P5_utils.plot_history(history)
                
            # Evaluar la red
            train_score = model.evaluate(x_train, y_train, verbose=0)
            test_score = model.evaluate(x_test, y_test, verbose=0)
            print('------------------------------------')
            print('------------------------------------')
            print('El algoritmo de activacion es:')
            print(i)
            print('El algoritmo de entrenamiento es:')
            print(x)
            print('La funcion de coste es:')
            print(j)
            print('%s %2.2f%s' % ('Accuracy train: ', 100*train_score[1], '%' ))
            print('%s %2.2f%s' % ('Accuracy test:  ', 100*test_score[1], '%'))
            print('------------------------------------')
            print('------------------------------------')            
                
            y_pred = model.predict(x_test)
            P5_utils.plot_mnist_confusion_matrix(y_test, y_pred)
            print('------------------------------------') 




print("")
print("Pruebas para una sola capa oculta")
print("")
# Función para parar cuando ya no mejora el error de validacion
earlystop=EarlyStopping(monitor='val_loss', patience=5, 
                        verbose=1, mode='auto')

optimizadores = ['sgd','adam','rmsprop']
funcion_coste = ['categorical_crossentropy','mean_squared_error']
funcion_activacion = ['relu','sigmoid']
salida = ['sigmoid','softmax']
neuronas = [10,64,128]
for a in funcion_activacion:
    for z in neuronas:  
        for i in salida:       
            for x in optimizadores:        
                for j in funcion_coste:
                     
                    model = Sequential()
                    #Capa oculta
                    model.add(Dense(z, activation=a, input_shape=(num_pixels,)))
                    model.add(Dropout(0.2))
                    #Capa de salida
                    model.add(Dense(units=10, activation=i)) 
                    model.compile(loss=j,
                              optimizer=x,
                              metrics=['accuracy'])
                    

                    t0 = time.clock()
                    
                    history = model.fit(x_train, y_train,
                                        batch_size=128,
                                        epochs=20,
                                        validation_split=0.1,
                                        callbacks=[earlystop],
                                        verbose=0)
                        
                    train_time = time.clock() - t0
    
                    P5_utils.plot_history(history)
                        
                    # Evaluar la red
                    train_score = model.evaluate(x_train, y_train, verbose=0)
                    test_score = model.evaluate(x_test, y_test, verbose=0)
                    print('------------------------------------')
                    print('%s %.3f%s' %  ('Training time: ', train_time, 's') )
                    print('Numero de neuronas')
                    print(z)
                    print('Capa oculta con relu,dropout')
                    print('El algoritmo de salida es:')
                    print(i)
                    print('El algoritmo de entrenamiento es:')
                    print(x)
                    print('La funcion de coste es:')
                    print(j)
                    print('%s %2.2f%s' % ('Accuracy train: ', 100*train_score[1], '%' ))
                    print('%s %2.2f%s' % ('Accuracy test:  ', 100*test_score[1], '%'))
                                  
                    y_pred = model.predict(x_test)
                    P5_utils.plot_mnist_confusion_matrix(y_test, y_pred)
                    print('------------------------------------') 





print("")
print("Pruebas para dos capas ocultas")
print("")
# Función para parar cuando ya no mejora el error de validacion
earlystop=EarlyStopping(monitor='val_loss', patience=5, 
                        verbose=1, mode='auto')

optimizadores = ['adam','rmsprop']
funcion_coste = ['categorical_crossentropy','mean_squared_error']
funcion_activacion = ['relu','sigmoid']
funcion_activacion2 = ['relu','sigmoid']
#En estas pruebas la función de salida va a ser siempre softmax
salida = ['softmax']
neuronas = [64,128]
for a in funcion_activacion:
    for b in funcion_activacion2:
        for z in neuronas:  
            for i in salida:       
                for x in optimizadores:        
                    for j in funcion_coste:
                                
                        model = Sequential()
                        #Primera capa oculta
                        model.add(Dense(z, activation=a, input_shape=(num_pixels,)))
                        model.add(Dropout(0.2))
                        #Segunda capa oculta
                        model.add(Dense(units=z, activation=b))
                        model.add(Dropout(0.2))
                        #Capa de salida con softmax
                        model.add(Dense(units=10, activation=i)) 
                        model.compile(loss=j,
                                  optimizer=x,
                                  metrics=['accuracy'])
                        
                        t0 = time.clock()
                        history = model.fit(x_train, y_train,
                                            batch_size=128,
                                            epochs=20,
                                            validation_split=0.1,
                                            callbacks=[earlystop],
                                            verbose=0)
                            
                        train_time = time.clock() - t0
        
                        P5_utils.plot_history(history)
                            
                        # Evaluar la red
                        train_score = model.evaluate(x_train, y_train, verbose=0)
                        test_score = model.evaluate(x_test, y_test, verbose=0)
                        print('------------------------------------')
                        print('%s %.3f%s' %  ('Training time: ', train_time, 's') )
                        print('Numero de neuronas')
                        print(z)
                        print('Primera capa oculta')
                        print (a)
                        print('Segunda capa oculta')
                        print(b)
                        print('El algoritmo de salida es:')
                        print(i)
                        print('El algoritmo de entrenamiento es:')
                        print(x)
                        print('La funcion de coste es:')
                        print(j)
                        print('%s %2.2f%s' % ('Accuracy train: ', 100*train_score[1], '%' ))
                        print('%s %2.2f%s' % ('Accuracy test:  ', 100*test_score[1], '%'))
                                      
                        y_pred = model.predict(x_test)
                        P5_utils.plot_mnist_confusion_matrix(y_test, y_pred)
                        print('------------------------------------') 