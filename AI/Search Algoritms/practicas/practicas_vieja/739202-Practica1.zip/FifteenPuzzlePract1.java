package aima.gui.demo.search;

import java.util.List;
import aima.core.agent.Action;
import aima.core.environment.fifteenpuzzle.FifteenPuzzleBoard;
import aima.core.environment.fifteenpuzzle.FifteenPuzzleFunctionFactory;
import aima.core.environment.fifteenpuzzle.FifteenPuzzleGoalTest;
import aima.core.search.framework.GraphSearch;
import aima.core.search.framework.Problem;
import aima.core.search.framework.ResultFunction;
import aima.core.search.framework.Search;
import aima.core.search.framework.SearchAgent;
import aima.core.search.framework.TreeSearch;
import aima.core.search.uninformed.BreadthFirstSearch;
import aima.core.search.uninformed.DepthFirstSearch;
import aima.core.search.uninformed.DepthLimitedSearch;
import aima.core.search.uninformed.IterativeDeepeningSearch;
import aima.core.search.uninformed.UniformCostSearch;

/**
 * @author Luis Garcia Garces 739202
 * 
 */

public class FifteenPuzzlePract1 {
	
	static FifteenPuzzleBoard boardWithThreeMoveSolution = new FifteenPuzzleBoard(
			new int[] { 1, 2, 6, 3, 4, 5, 0, 7, 8, 9, 10, 11, 12, 13, 14, 15 });

		static FifteenPuzzleBoard random1 = new FifteenPuzzleBoard(
			new int[] { 1, 2, 3, 7, 4, 5, 6, 11, 8, 9, 10, 15, 0, 12, 13, 14 });

		static FifteenPuzzleBoard extreme = new FifteenPuzzleBoard(
			new int[] { 13, 5, 12, 4, 0, 15, 9, 6, 14, 1, 8, 7, 3, 11, 2, 10 });

	public static void main(String[] args) {
		System.out.printf("  Problema|Profundidad|    Expand| 	   Q.Size| 	    MaxQS| 		tiempo\n");
		//B�squedas en grafo
		fifteenSearch(new BreadthFirstSearch(new GraphSearch()), boardWithThreeMoveSolution,"BFS-G-3",true,"null");
		fifteenSearch(new BreadthFirstSearch(new GraphSearch()),random1,"BFS-G-9",true,"null");
		fifteenSearch(new BreadthFirstSearch(new GraphSearch()),extreme,"BFS-G-30",false,"(1)");
		
		fifteenSearch(new DepthFirstSearch(new GraphSearch()),boardWithThreeMoveSolution,"DFS-G-3",false,"(1)");
		fifteenSearch(new DepthFirstSearch(new GraphSearch()),random1,"DFS-G-9",false,"(2)");
		fifteenSearch(new DepthFirstSearch(new GraphSearch()),extreme,"DFS-G-30",false,"(2)");
		//------------------------
		fifteenSearch(new UniformCostSearch(new GraphSearch()),boardWithThreeMoveSolution,"UCS-G-3",true,"null");
		fifteenSearch(new UniformCostSearch(new GraphSearch()),random1,"UCS-G-9",true,"null");
		fifteenSearch(new UniformCostSearch(new GraphSearch()),extreme,"UCS-G-30",false,"(2)");
		


		fifteenSearch(new BreadthFirstSearch(new TreeSearch()),boardWithThreeMoveSolution,"BFS-T-3",true,"null");
		fifteenSearch(new BreadthFirstSearch(new TreeSearch()),random1,"BFS-T-9",true,"null");
		fifteenSearch(new BreadthFirstSearch(new TreeSearch()),extreme,"BFS-T-30",false,"(1)");

		fifteenSearch(new DepthFirstSearch(new TreeSearch()),boardWithThreeMoveSolution,"DFS-T-3",false,"(2)");
		fifteenSearch(new DepthFirstSearch(new TreeSearch()),random1,"DFS-T-9",false,"(1)");
		fifteenSearch(new DepthFirstSearch(new TreeSearch()),extreme,"DFS-T-30",false,"(1)");

		fifteenSearch(new UniformCostSearch(new TreeSearch()),boardWithThreeMoveSolution,"UCS-T-3",true,"null");
		fifteenSearch(new UniformCostSearch(new TreeSearch()),random1,"UCS-T-9",true,"null");
		fifteenSearch(new UniformCostSearch(new TreeSearch()),extreme,"UCS-T-30",false,"(1)");
		
		//Busquedas Iterativa en Profundidadll-
		fifteenSearch(new IterativeDeepeningSearch(),boardWithThreeMoveSolution,"IDS-3",true,"null");
		fifteenSearch(new IterativeDeepeningSearch(),random1,"IDS-9",true,"null");
		fifteenSearch(new IterativeDeepeningSearch(),extreme,"IDS-30",false,"(1)");
		
		//Busquedas en profundida limitada
		fifteenSearch(new DepthLimitedSearch(3),boardWithThreeMoveSolution,"DLS-3-3",true,"null");
		fifteenSearch(new DepthLimitedSearch(3),random1,"DLS-3-9",true,"null");
		fifteenSearch(new DepthLimitedSearch(3),extreme,"DLS-3-30",true,"null");
		
		fifteenSearch(new DepthLimitedSearch(9),boardWithThreeMoveSolution,"DLS-9-3",true,"null");
		fifteenSearch(new DepthLimitedSearch(9),random1,"DLS-9-9",true,"null");
		fifteenSearch(new DepthLimitedSearch(9),extreme,"DLS-9-30",true,"null");
		
		fifteenSearch(new DepthLimitedSearch(30),boardWithThreeMoveSolution,"DLS-30-3",true,"null");
		fifteenSearch(new DepthLimitedSearch(30),random1,"DLS-30-9",true,"null");
		fifteenSearch(new DepthLimitedSearch(30),extreme,"DLS-30-30",false,"(1)");
		
		
	}
	private static void fifteenSearch(Search search,FifteenPuzzleBoard tablero,String algoritmo,boolean finalizado,String termina) {
		
			try {
				String pathcostM, depth,expandedNodes,queueSize,maxQueueSize,duracion;
			if(finalizado) {	
				Problem problem = new Problem(tablero, FifteenPuzzleFunctionFactory
						.getActionsFunction(), FifteenPuzzleFunctionFactory
						.getResultFunction(), new FifteenPuzzleGoalTest());
				
				
				long t1=System.currentTimeMillis();
				SearchAgent agent =new SearchAgent(problem, search);
				long t2=System.currentTimeMillis();
				long timeDif =t2-t1;
				
				duracion=String.valueOf(timeDif);
				
				pathcostM =agent.getInstrumentation().getProperty("pathCost");
				if(pathcostM!=null)depth=String.valueOf((int)Float.parseFloat(pathcostM));
				else depth="0";
				if(agent.getInstrumentation().getProperty("nodesExpanded")==null)expandedNodes="0";
				else expandedNodes=String.valueOf(agent.getInstrumentation().getProperty("nodesExpanded"));
				if(agent.getInstrumentation().getProperty("queueSize")==null)queueSize="0";
				else queueSize=String.valueOf(agent.getInstrumentation().getProperty("queueSize"));
				if(agent.getInstrumentation().getProperty("maxQueueSize")==null)maxQueueSize="0";
				else maxQueueSize=String.valueOf(agent.getInstrumentation().getProperty("maxQueueSize"));
			
			
			
			}
			else {
				pathcostM="---";		
				depth="---";
				expandedNodes="---";
				queueSize="---";
				maxQueueSize="---";
				duracion=termina;
				
			}
			//Muestra por pantalla el resultado con el siguiente formato:
			//  Problema|   Profunidad|   Expanded|       Q.zise|         MaxQS|        tiempo
			System.out.printf("%10s|%11s|%10s|%15s|%15s|%15s\n",algoritmo,depth,expandedNodes,queueSize,maxQueueSize,duracion);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	

	}
	
	public static void executeActions(List<Action> actions,Problem problem) {
		Object initialState= problem.getInitialState();
		ResultFunction resultFunction = problem.getResultFunction();
		
		Object state =initialState;
		System.out.println("INITIAL STATE");
		System.out.println(state);
		
		
		for(Action action: actions) {
			
			System.out.println(action.toString());
			state= resultFunction.result(state, action);
			System.out.println(state);			
			System.out.println("- - -");
			
			
		}
		
	}

}