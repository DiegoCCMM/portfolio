package aima.gui.demo.search;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import aima.core.agent.Action;
import aima.core.environment.Canibales.CanibalesBoard;
import aima.core.environment.Canibales.CanibalesFunctionFactory;
import aima.core.environment.Canibales.CanibalesGoalTest;
import aima.core.search.framework.GraphSearch;
import aima.core.search.framework.Problem;
import aima.core.search.framework.ResultFunction;
import aima.core.search.framework.Search;
import aima.core.search.framework.SearchAgent;
import aima.core.search.framework.TreeSearch;
import aima.core.search.uninformed.BreadthFirstSearch;
import aima.core.search.uninformed.DepthFirstSearch;
import aima.core.search.uninformed.DepthLimitedSearch;
import aima.core.search.uninformed.IterativeDeepeningSearch;
import aima.core.search.uninformed.UniformCostSearch;
/**
 * @author Luis Garcia Garces 739202
 * 
 */

public class CanibalesDemo {	
	static CanibalesBoard inicio = new CanibalesBoard();

	public static void main(String[] args) {
		//B�squedas en grafo
		CanibalesSearch(new BreadthFirstSearch(new GraphSearch()),inicio,"Misioneres y Canibales BFS-G",true,"null");
		
		CanibalesSearch(new DepthFirstSearch(new GraphSearch()),inicio,"Misioneres y Canibales DFS-G",true,"null");

		CanibalesSearch(new UniformCostSearch(new GraphSearch()),inicio,"Misioneres y Canibales UCS-G",true,"null");

		//B�squedas en �rbol
		CanibalesSearch(new BreadthFirstSearch(new TreeSearch()),inicio,"Misioneres y Canibales BFS-T",true,"null");
		
		CanibalesSearch(new DepthFirstSearch(new TreeSearch()),inicio,"Misioneres y Canibales DFS-T",false,"(1)");
				
		CanibalesSearch(new UniformCostSearch(new TreeSearch()),inicio,"Misioneres y Canibales UCS-T",true,"null");
				
		//Busquedas Iterativa en Profundidad
		CanibalesSearch(new IterativeDeepeningSearch(),inicio,"Misioneres y Canibales IDS",true,"null");
		
		//Busquedas en profundida limitada
		//La profunidad no es suficiente para encontrar la solucion
		CanibalesSearch(new DepthLimitedSearch(3),inicio,"Misioneres y Canibales  DLS-3",false,"(2)");

		//La profunidad no es suficiente para encontrar la solucion
		CanibalesSearch(new DepthLimitedSearch(9),inicio,"Misioneres y Canibales  DLS-9",false,"(3)");
		
		
		CanibalesSearch(new DepthLimitedSearch(30),inicio,"Misioneres y Canibales  DLS-30",true,"null");

	}
	
	private static void CanibalesSearch(Search search,CanibalesBoard tablero,String algoritmo,boolean finalizado,String termina) {
		
		try {
			String pathcostM, depth, expandedNodes, queueSize, maxQueueSize, duracion;
			
		if(finalizado) {	

			Problem problem = new Problem(tablero, CanibalesFunctionFactory
					.getActionsFunction(), CanibalesFunctionFactory
					.getResultFunction(), new CanibalesGoalTest());
			
			long t1=System.currentTimeMillis();
			SearchAgent agent =new SearchAgent(problem, search);
			long t2=System.currentTimeMillis();
			long timeDif =t2-t1;
			
			duracion=String.valueOf(timeDif);
			
			pathcostM =agent.getInstrumentation().getProperty("pathCost");
			if(pathcostM!=null)depth=String.valueOf((int)Float.parseFloat(pathcostM));
			else depth="0";
			if(agent.getInstrumentation().getProperty("nodesExpanded")==null)expandedNodes="0";
			else expandedNodes=String.valueOf(agent.getInstrumentation().getProperty("nodesExpanded"));
			if(agent.getInstrumentation().getProperty("queueSize")==null)queueSize="0";
			else queueSize=String.valueOf(agent.getInstrumentation().getProperty("queueSize"));
			if(agent.getInstrumentation().getProperty("maxQueueSize")==null)maxQueueSize="0";
			else maxQueueSize=String.valueOf(agent.getInstrumentation().getProperty("maxQueueSize"));
			
			mostrarResultado(algoritmo,pathcostM+".0", depth, expandedNodes,queueSize, maxQueueSize, duracion);
			executeActions(agent.getActions(), problem);
				
		}
		else {			
			mostrarResultado(algoritmo,"", "", "","", "", "");
			}
		System.out.printf("\n");
				
	} catch (Exception e) {
		e.printStackTrace();
	}


}
	private static void mostrarResultado(String algoritmo,String pathcostM,String depth,String expandedNodes,String queueSize,String maxQueueSize,String duracion) {
		System.out.printf("%s  -->\n",algoritmo);
		System.out.printf("pathCost: %s \n",depth);
		System.out.printf("expandedNodes: %s \n",expandedNodes);
		System.out.printf("queueSize: %s \n",queueSize);
		System.out.printf("maxQueueSize: %s \n",maxQueueSize);
		System.out.printf("Tiempo: %smls \n",duracion);
		System.out.printf("SOLUCION: \n");
		System.out.printf("GOAL STATE: \n");
		System.out.printf("RIBERA-IZQ --RIO--BOTE M M M C C C RIBERA-DCH \n");
		System.out.printf("CAMINO ENCONTRADO \n");
		
	}

	private static void printInstrumentation(Properties properties) {
		Iterator<Object> keys = properties.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String property = properties.getProperty(key);
			System.out.println(key + " : " + property);
		}

	}

	private static void printActions(List<Action> actions) {
		for (int i = 0; i < actions.size(); i++) {
			String action = actions.get(i).toString();
			System.out.println(action);
		}
	}
	
	public static void executeActions(List<Action> actions,Problem problem) {
		Object initialState= problem.getInitialState();
		ResultFunction resultFunction = problem.getResultFunction();
		
		Object state =initialState;
		System.out.println("INITIAL STATE");
		System.out.println(state);
		
		
		for(Action action: actions) {
			
			System.out.println(action.toString());
			state= resultFunction.result(state, action);
			System.out.println(state);									
		}
		
	}

}