package aima.core.environment.Canibales;

import java.util.Arrays;

import aima.core.agent.Action;
import aima.core.agent.impl.DynamicAction;


/**
 * @author Luis Garcia Garces 739202
 */
public class CanibalesBoard {
	
	//Movimientos a la izquierda
	public static Action IZQ_M2 = new DynamicAction("IZQ_M2");
	public static Action IZQ_C2 = new DynamicAction("IZQ_C2");
	public static Action IZQ_M1 = new DynamicAction("IZQ_M1");
	public static Action IZQ_C1 = new DynamicAction("IZQ_C1");
	public static Action IZQ_MC = new DynamicAction("IZQ_MC");

	//Movimientos a la derecha
	public static Action DER_M2 = new DynamicAction("DER_M2");
	public static Action DER_C2 = new DynamicAction("DER_C2");
	public static Action DER_M1 = new DynamicAction("DER_M1");
	public static Action DER_C1 = new DynamicAction("DER_C1");
	public static Action DER_MC = new DynamicAction("DER_MC");
	
	private int[] state;

	//
	// PUBLIC METHODS
	//
	//Misioneros state[0][4]
	//Canibales state[1][3]
	public CanibalesBoard() {
		state = new int[] { 3, 3, 1, 0, 0};
	}
	//La barca, 1 izquierda, 0 derecha
	
	public CanibalesBoard(int[] state) {
		this.state = new int[state.length];
		System.arraycopy(state, 0, this.state, 0, state.length);
	}

	public CanibalesBoard(CanibalesBoard copyBoard) {
		this(copyBoard.getState());
	}

	
	public int[] getState() {
		return state;
	}

	//Funcion para moverse de  izquierda a derecha	
	//Misioneros state[0][4]
	//Canibales state[1][3]
	public boolean canMoveDer(Action where) {
		boolean retVal = true;
		if (where.equals(DER_M1))
			//Mover un Misionero
			retVal = (state[0]>=1 &&(state[0]>=state[1]+1 || state[0]==1)&& (state[4]>=state[3]-1));
		else if (where.equals(DER_C1))
			//Mover un canibal,estamos en la izquierda
			retVal = (state[1]>=1 && ((state[4]>=state[3]+1)|| state[4]==0) );
		else if (where.equals(DER_C2))
			//Mover 2 canibales,
			retVal = (state[1]>=1  && ((state[4]>=state[3]+2)|| state[4]==0));
		else if (where.equals(DER_M2))
			retVal = ((state[0]>=2 &&(state[0]>=state[1]+2 || state[0]==2)&& (state[4]>=state[3]-2)));
		else if (where.equals(DER_MC))
			retVal = (state[0]>=1 && state[1]>=1  && (state[4]>=state[3]));
		return (retVal && (state[2]==1));
	}
	
	//Funcion para moverse de derecha a izquierda
	public boolean canMoveIzq(Action where) {
		
		boolean retVal = true;
		if (where.equals(IZQ_M1))
			//Mover un Misionero
			retVal = (state[4]>=1 && (state[4]>=state[3]+1 || state[4]==1)&& (state[0]>=state[1]-1) );
		else if (where.equals(IZQ_C1))
			//Mover un canibal,estamos en la derecha
			retVal = (state[3]>=1 && ((state[0]>=state[1]+1)|| state[0]==0));
		else if (where.equals(IZQ_C2))
			retVal = (state[3]>=2 && ((state[0]>=state[1]+2)|| state[0]==0));
		else if (where.equals(IZQ_M2))
			retVal = (state[4]>=2 &&(state[4]>=state[3]+2 || state[4]==2)&& (state[0]>=state[1]-2));
		else if (where.equals(IZQ_MC))
			retVal = (state[3]>=1 && state[4]>=1  && (state[0]>=state[1]));
		return (retVal&& (state[2]==0));
	}
	//Movimientos a la derecha
	public void MovDerecha(Action where) {
			int m=0; int c=0;
			if(where.equals(DER_C1)) {
				c++;
			}else if(where.equals(DER_M1)) {
				m++;
			}else if(where.equals(DER_M2)) {
				m=+2;
			}else if(where.equals(DER_C2)) {
				c=+2;
			}else if(where.equals(DER_MC)) {
				c++;m++;
			}
			//Desplazo los misioneros y canibales a la derecha
			state[0]-=m;
			state[1]-=c;
			state[2]=0;
			state[4]+=m;
			state[3]+=c;
			
	}
	//Movimientos a la derecha
		public void MovIzquierda(Action where) {
				int m=0; int c=0;
				if(where.equals(IZQ_C1)) {
					c++;
				}else if(where.equals(IZQ_M1)) {
					m++;
				}else if(where.equals(IZQ_M2)) {
					m=+2;
				}else if(where.equals(IZQ_C2)) {
					c=+2;
				}else if(where.equals(IZQ_MC)) {
					c++;m++;
				}
				//Desplazo los misioneros y canibales a la izquierda
				state[4]-=m;
				state[3]-=c;
				state[2]=1;
				state[0]+=m;
				state[1]+=c;
			
		}

	@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Arrays.hashCode(state);
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CanibalesBoard other = (CanibalesBoard) obj;
			if (!Arrays.equals(state, other.state))
				return false;
			return true;
		}

	@Override
	public String toString() {
		String retVal="RIBERA-IZQ ";
		retVal+=mostrarMisioneros(state[0]);
		retVal+=mostrarCanibales(state[1]);
		if(state[2]==1) {
			retVal+=" BOTE ---RIO--- ";
		}
		else {
			retVal+="---RIO---  BOTE ";
		}
		retVal+=mostrarCanibales(state[3]);
		retVal+=mostrarMisioneros(state[4]);
		retVal+=" RIBERA-DCH";
		
		return retVal;
	}
	String mostrarCanibales(int n) {
		String d="";
		if(n==1) {
			d="C   ";
		}else if(n==2) {
			d="CC  ";
			
		}else if(n==3) {
			d="CCC ";
		}else {
			d="    ";
		}	
		return d;
	}
	String mostrarMisioneros(int n) {
		String d="";
		if(n==1) {
			d="M   ";
		}else if(n==2) {
			d="MM  ";
			
		}else if(n==3) {
			d="MMM ";
		}else {
			d="    ";
		}		
		return d;
	}
}