package aima.core.environment.Canibales;

import java.util.LinkedHashSet;
import java.util.Set;

import aima.core.agent.Action;
import aima.core.search.framework.ActionsFunction;
import aima.core.search.framework.ResultFunction;

/**
 * @author  Luis Garcia Garces 739202
 */
public class CanibalesFunctionFactory {
	private static ActionsFunction _actionsFunction = null;
	private static ResultFunction _resultFunction = null;

	public static ActionsFunction getActionsFunction() {
		if (null == _actionsFunction) {
			_actionsFunction = new EPActionsFunction();
		}
		return _actionsFunction;
	}

	public static ResultFunction getResultFunction() {
		if (null == _resultFunction) {
			_resultFunction = new EPResultFunction();
		}
		return _resultFunction;
	}

	private static class EPActionsFunction implements ActionsFunction {
		public Set<Action> actions(Object state) {
			CanibalesBoard board = (CanibalesBoard) state;

			Set<Action> actions = new LinkedHashSet<Action>();
			//Movimientos a la derecha

			if (board.canMoveDer(CanibalesBoard.DER_M2)) {
				actions.add(CanibalesBoard.DER_M2);
			}
			if (board.canMoveDer(CanibalesBoard.DER_M1)) {
				actions.add(CanibalesBoard.DER_M1);
			}
			if (board.canMoveDer(CanibalesBoard.DER_C1)) {
				actions.add(CanibalesBoard.DER_C1);
			}
			if (board.canMoveDer(CanibalesBoard.DER_C2)) {
				actions.add(CanibalesBoard.DER_C2);
			}
			if (board.canMoveDer(CanibalesBoard.DER_MC)) {
				actions.add(CanibalesBoard.DER_MC);
			}
			//Movimientos a la izquierda
			if (board.canMoveIzq(CanibalesBoard.IZQ_M2)) {
				actions.add(CanibalesBoard.IZQ_M2);
			}
			if (board.canMoveIzq(CanibalesBoard.IZQ_M1)) {
				actions.add(CanibalesBoard.IZQ_M1);
			}
			if (board.canMoveIzq(CanibalesBoard.IZQ_C1)) {
				actions.add(CanibalesBoard.IZQ_C1);
			}
			if (board.canMoveIzq(CanibalesBoard.IZQ_C2)) {
				actions.add(CanibalesBoard.IZQ_C2);
			}
			if (board.canMoveIzq(CanibalesBoard.IZQ_MC)) {
				actions.add(CanibalesBoard.IZQ_MC);
			}

			return actions;
		}
	}

	private static class EPResultFunction implements ResultFunction {
		public Object result(Object s, Action a) {
			CanibalesBoard board = (CanibalesBoard) s;
			
			if (CanibalesBoard.DER_C1.equals(a)//1 derecha
					&& board.canMoveDer(CanibalesBoard.DER_C1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovDerecha(CanibalesBoard.DER_C1);
				return newBoard;
				
			} else if (CanibalesBoard.DER_C2.equals(a)//2 derecha
					&& board.canMoveDer(CanibalesBoard.DER_C2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovDerecha(CanibalesBoard.DER_C2);
				return newBoard;
				
			}
			else if (CanibalesBoard.DER_M2.equals(a)//3 derecha
					&& board.canMoveDer(CanibalesBoard.DER_M2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovDerecha(CanibalesBoard.DER_M2);
				return newBoard;
				
			}
			else if (CanibalesBoard.DER_M1.equals(a)//4 derecha
					&& board.canMoveDer(CanibalesBoard.DER_M1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovDerecha(CanibalesBoard.DER_M1);
				return newBoard;
				
			}
			else if (CanibalesBoard.DER_MC.equals(a)//5 derecha
					&& board.canMoveDer(CanibalesBoard.DER_MC)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovDerecha(CanibalesBoard.DER_MC);
				return newBoard;
				
			} 

			else if (CanibalesBoard.IZQ_C1.equals(a)//1 izquierda
					&& board.canMoveIzq(CanibalesBoard.IZQ_C1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovIzquierda(CanibalesBoard.IZQ_C1);
				return newBoard;
				
			} else if (CanibalesBoard.IZQ_C2.equals(a)//2 izquierda
					&& board.canMoveIzq(CanibalesBoard.IZQ_C2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovIzquierda(CanibalesBoard.IZQ_C2);
				return newBoard;
				
			}
			else if (CanibalesBoard.IZQ_M2.equals(a)//3 izquierda
					&& board.canMoveIzq(CanibalesBoard.IZQ_M2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovIzquierda(CanibalesBoard.IZQ_M2);
				return newBoard;
				
			}
			else if (CanibalesBoard.IZQ_M1.equals(a)//4 izquierda
					&& board.canMoveIzq(CanibalesBoard.IZQ_M1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovIzquierda(CanibalesBoard.IZQ_M1);
				return newBoard;
				
			}
			else if (CanibalesBoard.IZQ_MC.equals(a)//5 izquierda
					&& board.canMoveIzq(CanibalesBoard.IZQ_MC)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.MovIzquierda(CanibalesBoard.IZQ_MC);
				return newBoard;
				
			}

			// The Action is not understood or is a NoOp
			// the result will be the current state.
			return s;
		}
	}
}