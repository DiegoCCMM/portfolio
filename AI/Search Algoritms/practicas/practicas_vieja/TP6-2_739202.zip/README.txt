Autor: Luis García Garcés 739202

1. Ejecute en un terminal de python: run TP6-2.py
2. Aparecerá el siguiente mensaje: "Por favor introduzca el directorio donde se encuentran los correos: "
	Introduzca la ruta donde se encuentran las enron con los correos.
	Ejemplo:
		carpetaCorreos\
	El programa se encargará de completar carpetaCorreos\enron1, carpetaCorreos\enron2...
	Usted solo tiene que espeficar en qué carpeta se encuentran las carpetas de los correos y añadir
	\ al final.
	Por favor no introduzca '.\' si se encuentra en la misma carpeta que el script, para ello simplemente
	pulse enter.

