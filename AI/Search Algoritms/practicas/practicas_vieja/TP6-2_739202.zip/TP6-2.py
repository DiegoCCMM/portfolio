#TP6 Inteligencia Artificial
#Luis García Garcés
#739202

######################################################
# Imports
######################################################

import numpy as np
import json
import glob
import sys
import time
from sklearn.metrics import confusion_matrix, f1_score, precision_recall_curve
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.utils import shuffle
from sklearn import metrics
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold

######################################################
# Functions for evaluating mails
######################################################

def kfold_cross_validation(Learner,k,bow_train,label_train):
    #Calcularemos cual es el mejor suavizado de Laplace en función
    #de los resultados obtenidos en la función f1_score
    best_size=0
    best_score=0
    #Valor inicial del suavizado de Laplace
    i=0.25
  
    labels_list = np.array(label_train)
    while i<5:
        current_score=0
        #Partiremos los datos de entrenamiento 5 veces
        kf = KFold(n_splits=5)                
        #Forma de iterar con KFold
        for i_mail, i_test in kf.split(bow_train):
            #Datos para entrenamiento
            mail_train=bow_train[i_mail]
            label_train=labels_list[i_mail]
            
            #Datos para verificar
            mail_test=bow_train[i_test]
            label_test=labels_list[i_test]
            
            if (Learner == 0):
               classifier=MultinomialNB(alpha=i)
                
            else:
                classifier=BernoulliNB(alpha=i)
                
            classifier.fit(mail_train,label_train)
            predicion=classifier.predict(mail_test)            
            current_score+=f1_score(label_test,predicion)
            
        media_score=current_score/k
        
        if media_score>best_score:
            best_size=i
            best_score=media_score
        i+=0.25
            
    #Devuelve el mejor suavizado de laplace
    return best_size

#Entrena con el mejor suavizado de laplace y todos los datos
def train_best(best_size,metodo,bow_train,label_train):
    if metodo==0:
        classifier=MultinomialNB(alpha=best_size)
    else:
        classifier=BernoulliNB(alpha=best_size)
                
    classifier.fit(bow_train,label_train)                
    return classifier



def Evaluar_resultados(lista_predicciones,lista_predicciones_2,mails_test, label_test,lista_laplace):
    best_prediccion=0
    best_score=0
    best_laplace=0
    best_nombre=''
    plt.clf()
    #Comprobamos si MultinomialNB o BernoulliNB obtiene el mejor resultado
    #para f1_score
    for i in range(4):
        score=f1_score(label_test,lista_predicciones[i])
        confusion=confusion_matrix(label_test,lista_predicciones[i])
        accuracy=accuracy_score(label_test,lista_predicciones[i])
        if (i==0):
            nombre='MultinomialNB con bolsa de palabras'
        elif (i==1):
            nombre='BernoulliNB con bolsa de palabras'
            
        elif(i==2):
            nombre='MultinomialNB con bigrama'
        else:
            nombre='BernoulliNB con bigrama'
            
        if (score>best_score) :
            best_score=score
            best_laplace=lista_laplace[i]
            best_confusion=confusion
            best_prediccion=lista_predicciones[i]
            best_prediccion_2=lista_predicciones_2[i]
            best_nombre=nombre
            best_accuracy=accuracy
            
        print("El f1_score de :",nombre)
        print(score)
        print("Accurcay score de :",nombre)
        print(accuracy)
        print("Matriz de confusion para :",nombre)
        print(confusion)
        print('')
        print("Suavizado de Laplace:",lista_laplace[i])
        print('')

    
    precisiones,recall,threshold=precision_recall_curve(label_test,best_prediccion_2)          
    plt.plot(recall,precisiones,label=nombre)    
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.ylim([0.9, 1.05])
    plt.xlim([0.9, 1.05])    
    plt.show()
    
    print("Mostrar los resultados del mejor.")
    print("")
    print("Suavizado de Laplace utilizado en :",best_nombre)
    print(best_laplace)
    print("Accurcay score de :",best_nombre)
    print(best_accuracy)
    print("El f1_score de :",best_nombre)    
    print(best_score)
    print("Matriz de confusion para :",best_nombre)
    print(best_confusion)
    
    
    lista_ham=[]
    lista_spam=[]
    lista_ham_erroneos=[]
    lista_spam_erroneos=[]

    #Comprobamos cuáles de las predicciones han sido correctas y cuales
    #han sido falsas predicciones
    for i in range(0,len(label_test)):
        #En las label el correo es un ham
        if(label_test[i]==0):
            if(best_prediccion[i] ==0):
                #Ha sido predicho correctamente como un ham
                lista_ham.append(mails_test[i])
            else:
                #Era un ham, pero lo hemos detectado como un spam
                # es un falso spam
                lista_spam_erroneos.append(mails_test[i])
        else:
            #En las labels el correo es un spam
            if(best_prediccion[i] ==0):
                #En la predicción ha sido detectado como un ham,
                #es un falso ham
                lista_ham_erroneos.append(mails_test[i])
            else:
                #Ha detectado correctamente el spam
                lista_spam.append(mails_test[i])
                
    print("")            
    print("El numero de HAM detectados ha sido: ",len(lista_ham))
    print("El numero de SPAM detectados ha sido: ",len(lista_spam))
    print("El numero de falsos SPAM ha sido: ",len(lista_spam_erroneos))
    print("El numero de falsos HAM ha sido: ",len(lista_ham_erroneos))

    #Pasamos a mostrar un ejemplo de cada uno.
    print("")
    print("Mostrar ejemplos de mails")
    print("--------------------------")
    print("Ejemplo de un ham")
    print(lista_ham[1])
    print("--------------------------")
    print("")
    print("--------------------------")
    print("Ejemplo de un spam")
    print(lista_spam[2])
    print("--------------------------")
    print("")
    print("--------------------------")
    print("Ejemplo de un falso spam")
    print(lista_spam_erroneos[3])
    print("--------------------------")
    print("")
    print("--------------------------")
    print("Ejemplo de un falso ham")
    print(lista_ham_erroneos[1])
    print("")
    print("--------------------------")
    


def Calcular_resultados(mails_train, label_train,mails_test, label_test):
    #Lista para las predicciones de las clases
    lista_predicciones=[]
    #lista para las predicciones de las probabilidades de pertencer a cada clase
    lista_predicciones_2=[]
    #lista para los resultados de laplace
    lista_laplace=[]
    #Convert a collection of text documents to a matrix of token counts
    #Bolsa de palabras
    vectorizer  = CountVectorizer(ngram_range=(1,1))  # Initialize BOW structure
    #Recuento de cuantas veces aparece cada palabra en cada correo
    BOW_train = vectorizer.fit_transform(mails_train)     # BOW with word counts

    
    #Recuento de cada una de las veces que aparecen las palabras en cada correo de test
    BOW_test = vectorizer.transform(mails_test)          # BOW with word counts
        
    #Obtenemos el suavizado de Laplace que mejor f1_score ha proporcionado
    #0 se corresponde a MultinomialNB 
    laplace=kfold_cross_validation(0,5,BOW_train,label_train)
    lista_laplace.append(laplace)
    #Entrenamos con todos los datos de entrenamiento
    classifier=train_best(laplace,0,BOW_train,label_train)
    

    #Predecimos las probabilidades de pertenecer a cada clase de cada correo
    prediction_1=classifier.predict_proba(BOW_test)
    prediction_1=prediction_1[:, 1]

    lista_predicciones_2.append(prediction_1)
    
    #Predecimos a que clase pertenece cada correo
    prediction_1=classifier.predict(BOW_test)
    lista_predicciones.append(prediction_1)
    
    #BernoulliNB necesita que la bolsa de palabras se represente de forma binaria
    #Bolsa de palabras
    vectorizer  = CountVectorizer(ngram_range=(1,1),binary=1)
    BOW_train = vectorizer.fit_transform(mails_train)
    BOW_test = vectorizer.transform(mails_test)   

    #1 se corresponde a BernoulliNB
    laplace=kfold_cross_validation(1,5,BOW_train,label_train)
    lista_laplace.append(laplace)
    classifier=train_best(laplace,1,BOW_train,label_train)
    
    
    prediction_2=classifier.predict_proba(BOW_test)
    prediction_2=prediction_2[:, 1] 
    

    lista_predicciones_2.append(prediction_2)
    
    prediction_2=classifier.predict(BOW_test)
    lista_predicciones.append(prediction_2)
    
    
    
    #Bigramas
    
    vectorizer  = CountVectorizer(ngram_range=(1,2))
    BOW_train = vectorizer.fit_transform(mails_train)
    BOW_test = vectorizer.transform(mails_test)
    laplace=kfold_cross_validation(0,5,BOW_train,label_train)
    
    lista_laplace.append(laplace)
    #Entrenamos con todos los datos de entrenamiento
    classifier=train_best(laplace,0,BOW_train,label_train)
    
    
    prediction_1=classifier.predict_proba(BOW_test)
    prediction_1=prediction_1[:, 1]

    lista_predicciones_2.append(prediction_1)
    
    #Predecimos a que clase pertenece cada correo
    prediction_1=classifier.predict(BOW_test)
    lista_predicciones.append(prediction_1)
    
    #BernoulliNB necesita que la bolsa de palabras se represente de forma binaria
    #Bigramas
    vectorizer  = CountVectorizer(ngram_range=(1,2))
    BOW_train = vectorizer.fit_transform(mails_train)
    BOW_test = vectorizer.transform(mails_test)   

    #1 se corresponde a BernoulliNB
    laplace=kfold_cross_validation(1,5,BOW_train,label_train)
    lista_laplace.append(laplace)
    classifier=train_best(laplace,1,BOW_train,label_train)
    
    
    prediction_2=classifier.predict_proba(BOW_test)
    prediction_2=prediction_2[:, 1] 
    
    lista_predicciones_2.append(prediction_2)
    
    prediction_2=classifier.predict(BOW_test)
    lista_predicciones.append(prediction_2)
    
    #Procedemos a evaluar los resultados
    print("")
    Evaluar_resultados(lista_predicciones,lista_predicciones_2,mails_test, label_test,lista_laplace)
    print("")
    
        
######################################################
# Functions for loading mails
######################################################
                            
        
def read_folder(folder):
    mails = []
    file_list = glob.glob(folder)  # List mails in folder
    num_files = len(file_list)
    for i in range(0, num_files):
        i_path = file_list[i]
        # print(i_path)
        i_file = open(i_path, 'rb')
        i_str = i_file.read()
        i_text = i_str.decode('utf-8', errors='ignore')  # Convert to Unicode
        mails.append(i_text)  # Append to the mail structure
        i_file.close()
    return mails


def load_enron_folders(datasets,path):    
    ham = []
    spam = []
    for j in datasets:
        ham  = ham  + read_folder(path + 'enron' + str(j) + '\ham\*.txt')
        spam = spam + read_folder(path + 'enron' + str(j) + '\spam\*.txt')
    num_ham  = len(ham)
    num_spam = len(spam)
    print("mails:", num_ham+num_spam)
    print("ham  :", num_ham)
    print("spam :", num_spam)

    mails = ham + spam
    #En labels se encuentran que correos son spam y cuales no
    labels = [0]*num_ham + [1]*num_spam
    mails, labels = shuffle(mails, labels, random_state=0)

    return mails, labels

    
######################################################
# Main
######################################################


path = input("Por favor introduza el directorio donde se encuentran los correos: ")
print("Ubicacion introducida: " + path)

print("------Loading train and validation data--------")
mails_train, label_train = load_enron_folders([1,2,3,4,5],path)

print("--------------Loading Test data----------------")
mails_test, label_test = load_enron_folders([6],path)


print("La operación puede tardar unos segundos...")
t0 = time.clock()
Calcular_resultados(mails_train, label_train,mails_test, label_test)
train_time = time.clock() - t0
print('%s %.3f%s' %  ('Tiempo total transcurrido: ', train_time, 's') )
print("")
print("Fin del programa, hasta luego")










