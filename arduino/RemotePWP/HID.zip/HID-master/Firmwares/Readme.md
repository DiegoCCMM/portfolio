Firmwares
=========
[**See installing instructions on the Hoodloader repository**](https://github.com/NicoHood/Hoodloader)

You can also get the latest Hoodloader version or the dev version from this repository (select dev branch).

There are also other/older versions of the Hoodloader and the Lite Version for 8u2. The original firmware can also be found there.